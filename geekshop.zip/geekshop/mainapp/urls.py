
from django.urls import path
import mainapp.views as mainapp


app_name = 'mainapp'

urlpatterns = [
    # path('', mainapp.gallery, name='index'),
    path('', mainapp.GamesAllView.as_view(), name='index'),
    # path('gametypes/<types_pk>/', mainapp.gallery, name='gametypes'),
    # path('gametypes/<types_pk>/', mainapp.GamesView.as_view(), name='gametypes'),
    path('game/<int:pk>', mainapp.good, name='game'),
]
