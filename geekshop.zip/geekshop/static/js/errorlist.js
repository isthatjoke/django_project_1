'use strict';
let error = document.querySelectorAll('.errorlist');
error.forEach(element => element.style.display = "none");

