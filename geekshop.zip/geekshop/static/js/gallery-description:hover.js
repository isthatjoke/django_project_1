'use strict';
let desc = document.querySelector('.gallery-description');
let img = document.querySelector('.gallery-img');
desc.addEventListener('mouseover', () => {console.log(img);});