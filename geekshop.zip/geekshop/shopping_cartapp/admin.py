from django.contrib import admin

# Register your models here.
from shopping_cartapp.models import ShoppingCart

admin.site.register(ShoppingCart)
