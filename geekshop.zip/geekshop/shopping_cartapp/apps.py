from django.apps import AppConfig


class ShoppingCartappConfig(AppConfig):
    name = 'shopping_cartapp'
